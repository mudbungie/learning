rustc fuck_around.rs

cp fucking_around.service /etc/systemd/system/fucking_around.service
cp fuck_around /opt/fucking_around/fuck_around

systemctl daemon-reload
service fucking_around start